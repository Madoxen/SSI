using System.Collections.Generic;

namespace BasicClassifier
{
    public class IdentifiedObject
    {
        public List<string> properties = new List<string>();
        public string id;
    }


}