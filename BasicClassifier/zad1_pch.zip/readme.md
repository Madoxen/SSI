To start the program type
dotnet run data_file_name search_parameters_file

Compiled using dotnetcore 3.1